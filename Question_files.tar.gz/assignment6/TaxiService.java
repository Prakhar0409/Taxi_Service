public class TaxiService{

	public TaxiService() {
		// ...
	}

	public void performAction(String actionMessage) {
		System.out.println("action to be performed: " + actionMessage);
		//....
	}
}
